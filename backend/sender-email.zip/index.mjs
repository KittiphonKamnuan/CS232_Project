import nodemailer from "nodemailer";

export const handler = async (event) => {
  if (!event.body) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Request body is missing" }),
    };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Invalid JSON format" }),
    };
  }

  if (!body.customerEmail || !body.productName) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Missing required fields (customerEmail or productName)" }),
    };
  }

  const email = body.customerEmail;
  const productName = body.productName;
  const documentUrls = (Array.isArray(body.documentUrls) 
    ? body.documentUrls.filter(doc => doc && doc.url && doc.type)
    : []);

  console.log("Preparing to send email to:", email);

  ///ตั้งค่า user,password
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.GMAIL_USER || "<email>",
      pass: process.env.GMAIL_PASS || "<password>",
    },
  });

  const linkListHtml = documentUrls.length > 0
    ? documentUrls.map((doc) =>
        `<li><strong>${doc.type}:</strong> <a href="${doc.url}" target="_blank">${doc.url}</a></li>`
      ).join("")
    : "<li>ไม่มีลิงก์เอกสารแนบ</li>";

  const mailOptions = {
    from: 'InfoHub360 <infohub360service@gmail.com>',
    to: email,
    subject: `เอกสารสินค้า: ${productName}`,
    html: `
      <p>สวัสดีครับ/ค่ะ</p>
      <p>คุณได้รับอีเมลฉบับนี้จาก <strong>InfoHub360</strong></p>
      <p>เอกสารด้านล่างนี้คือเอกสารที่คุณได้ร้องขอเกี่ยวกับสินค้า: <strong>${productName}</strong></p>
      <ul>${linkListHtml}</ul>
      <p>หากคุณไม่ได้ร้องขออีเมลนี้ กรุณาละเลยข้อความนี้</p>
      <p>ขอบคุณครับ/ค่ะ</p>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully to:", email);
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: "Email sent successfully" }),
    };
  } catch (err) {
    console.error("Error sending email to:", email, err);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Failed to send email" }),
    };
  }
};